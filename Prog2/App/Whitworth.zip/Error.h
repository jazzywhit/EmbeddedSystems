/*
-----------------------------------------------------------------------
	                    Embedded Systems
                   Prog 2   -   Jesse Whitworth
-----------------------------------------------------------------------
			        Error.h
-----------------------------------------------------------------------*/
#ifndef ERROR_H
#define ERROR_H

#include "CPU.h"

void ShowError(const CPU_CHAR *message);

#endif
