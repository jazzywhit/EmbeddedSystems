/*
-----------------------------------------------------------------------
	                    Embedded Systems
                   Prog 2   -   Jesse Whitworth
-----------------------------------------------------------------------
			     pktParser.h
-----------------------------------------------------------------------*/

#ifndef PKTPARSER_H
#define PKTPARSER_H

void ParsePkt(void *pktBfr);

#endif
