  #ifndef REPLY_H
  #define REPLY_H
  /*--------------- R e p l y . h ---------------
  
  by: George Cheney
      ECE Dept.
      UMASS Lowell
  
  PURPOSE
  This is the interface to the Reply task module.
  
  CHANGES
  02-13-2012 gpc -  Created
  03-06-2012 gpc -  Updated for Program 5 and uC/OS-III
  */
  #include "BfrQ.h"
  
  #define ShortReplies
  
  /*----- f u n c t i o n    p r o t o t y p e s -----*/
  
  CPU_VOID ReplyCreate(BfrQ *replyBfrQ);
  CPU_VOID Reply(CPU_VOID *data);
  CPU_VOID ReplyPutMsg(BfrQ *replyBfrQ, const CPU_CHAR *msg);
  CPU_VOID ReplyError(BfrQ *replyBfrQ, const CPU_CHAR *msg);
  CPU_VOID BfrQPendRead(BfrQ *bfrQ);
  #endif