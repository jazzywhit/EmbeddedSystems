/*
-----------------------------------------------------------------------
	                    Embedded Systems
                   Prog 1   -   Jesse Whitworth
-----------------------------------------------------------------------
			              pktReader.h
-----------------------------------------------------------------------*/
#ifndef PKTREADER_H
#define PKETREADER_H

#include "CPU.h"

FILE* OpenPktFile();
CPU_INT16S	GetByte(FILE *pktFile);

#endif